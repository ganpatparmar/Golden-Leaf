package com.skyrider.goldenleaf;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

public class RegisterActivity extends AppCompatActivity {
    TextInputEditText textEmail,textPassword;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        textEmail= (TextInputEditText) findViewById(R.id.emil_ed_register);
        textPassword = (TextInputEditText) findViewById(R.id.pasword_ed_register);
        progressBar= (ProgressBar)findViewById(R.id.progressBarRegister);
    }

public void RegisterUser(View v)
{


}

}